package com.ibm.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.model.Customer;
@Component
public class CustomerDao {
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}
	@Transactional
	public int insert(Customer c) {
		String sql="insert into customer values(custseq.NEXTVAL,?,?,?,?,?)";
	int row=jdbcTemplate.update(sql,new Object[] {c.getName(),c.getPassword(),
	c.getEmail(),c.getGender(),c.getAge()});
	return row;
	}
@Transactional
public int update(Customer c) {
String sql="update customer set name=?,password=?,email=?,gender=?,age=? where custid=?";
	int row=jdbcTemplate.update(sql,new Object[] {c.getName(),c.getPassword(),
	c.getEmail(),c.getGender(),c.getAge(),c.getCustid()});
	return row;
	}
@Transactional
public int delete(int custid) {
		int row=jdbcTemplate.update("delete from customer where custid="+custid);
		return row;
	}

public List<Customer> getAllCustList(){
	ArrayList<Customer> custList=new ArrayList<>();
	jdbcTemplate.query("select * from customer", new ResultSetExtractor<List<Customer>>() {
	@Override
public List<Customer> extractData(ResultSet rs) throws SQLException, DataAccessException {
		while(rs.next()) {
			Customer c=new Customer();
			c.setCustid(rs.getInt(1));
			c.setName(rs.getString(2));
			c.setPassword(rs.getString(3));
			c.setEmail(rs.getString(4));
			c.setGender(rs.getString(5));
			c.setAge(rs.getInt(6));
			custList.add(c);
		}return custList;
		}
	});	return custList;
}
	public Customer findByCustomerId(int custid) {
		Customer c=new Customer();
		String sql="select * from Customer where custid=?";
jdbcTemplate.query(sql, new Object[] {custid}, new RowMapper<Customer>(){
	@Override
	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		c.setCustid(rs.getInt(1));
		c.setName(rs.getString(2));
		c.setPassword(rs.getString(3));
		c.setEmail(rs.getString(4));
		c.setGender(rs.getString(5));
		c.setAge(rs.getInt(6));
		return c;
	}});
return c;
	}
	
	@Transactional
	public int insertByNamed(Customer c) {
String sql="insert into customer values(custseq.NEXTVAL,:name,:password,:email,:gender,:age)";
Map<String,String> map=new HashMap<>();
map.put("name", c.getName());
map.put("password", c.getPassword());
map.put("email", c.getEmail());
map.put("gender", c.getGender());
map.put("age", Integer.toString(c.getAge()));
int row=namedParameterJdbcTemplate.update(sql,map);
	return row;
	}


public Customer validate(String username,String password) {
	 Customer c=new Customer();
	String sql="select * from Customer where name=? and password=?";
jdbcTemplate.query(sql, new Object[] {username,password}, new RowMapper<Customer>(){
@Override
public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {

	c.setCustid(rs.getInt(1));
	c.setName(rs.getString(2));
	c.setPassword(rs.getString(3));
	c.setEmail(rs.getString(4));
	c.setGender(rs.getString(5));
	c.setAge(rs.getInt(6));
	return c;
}});
return c;
}
}


