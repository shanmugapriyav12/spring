package com.ibm.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibm.dao.CustomerDao;
import com.ibm.model.Customer;

public class TestClient {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("myweb-servlet.xml");
		CustomerDao cdao=(CustomerDao)ctx.getBean("customerDao");
	//	Customer c1=new Customer("riya", "password", "riya@gmail.com", "Female", 23);
	//	System.out.println("Inserted :"+cdao.insert(c1));
		
		List<Customer> custList=cdao.getAllCustList();
		System.out.println(custList);

	}

}
