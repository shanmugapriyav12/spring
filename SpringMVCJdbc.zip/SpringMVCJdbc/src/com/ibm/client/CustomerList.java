package com.ibm.client;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ibm.model.Customer;

public class CustomerList implements ResultSetExtractor<List<Customer>> {

	ArrayList<Customer> custList=new ArrayList<>();
	@Override
	public List<Customer> extractData(ResultSet rs) throws SQLException, DataAccessException {
		while(rs.next()) {
					Customer c=new Customer();
					c.setCustid(rs.getInt(1));
					c.setName(rs.getString(2));
					c.setPassword(rs.getString(3));
					c.setEmail(rs.getString(4));
					c.setGender(rs.getString(5));
					c.setAge(rs.getInt(6));
					custList.add(c);
				}
		return custList;
	}

}
