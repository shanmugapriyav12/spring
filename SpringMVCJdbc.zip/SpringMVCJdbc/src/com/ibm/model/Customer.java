package com.ibm.model;



import java.io.Serializable;

import org.springframework.stereotype.Component;
import org.springmodules.validation.bean.conf.loader.annotation.handler.Email;
import org.springmodules.validation.bean.conf.loader.annotation.handler.Length;
import org.springmodules.validation.bean.conf.loader.annotation.handler.Min;
import org.springmodules.validation.bean.conf.loader.annotation.handler.NotBlank;
import org.springmodules.validation.bean.conf.loader.annotation.handler.NotNull;
@Component
public class Customer implements Serializable{
	private int custid;
	@NotBlank(message="Name Can't be Blank")
	private String name;
	@NotBlank(message="Password field must be filled")
	@Length(min=8,message="Minimum length is >= 8")
	private String password;
	@NotBlank(message="Email should be entered")
	@Email(message="Invalid Email")
	private String email;
	private String gender;
	@NotNull(message="Age can't be empty")
	@Min(value=18,message="Age must be > 18")
	private int age;
	public Customer() {
		super();
		}
	public Customer(String name, String password, String email, String gender, int age) {
		super();
		this.name = name;
		this.password = password;
		this.email = email;
		this.gender = gender;
		this.age = age;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", name=" + name + ", password=" + password + ", email=" + email
				+ ", gender=" + gender + ", age=" + age + "]";
	}
	
	
	
}
