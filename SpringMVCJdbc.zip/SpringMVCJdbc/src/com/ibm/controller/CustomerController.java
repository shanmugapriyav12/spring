package com.ibm.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.dao.CustomerDao;
import com.ibm.model.Customer;
import com.ibm.model.Gender;

@Controller
public class CustomerController {
	@Autowired
	CustomerDao customerDao;
	@Autowired
	Validator validator;
	@RequestMapping("/login")
	public String loginlink() {
		return "login";
	}
	@RequestMapping(value="/validate",method=RequestMethod.POST)
	public ModelAndView validate(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		Customer c=customerDao.validate(username, password);
		if(c!=null) {
			if(c.getName()!=null) {
			mv.addObject("username", username);
			mv.setViewName("home");
			}
		
		else {
			mv.addObject("error", "Invalid username/password");
			mv.setViewName("login");
		}
		}
		return mv;
		
	}
	
	@RequestMapping("/register")
	public ModelAndView reigterLink(ModelMap map) {
		Customer c=new Customer();
		map.addAttribute(c);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("register");
		return mv;
	}
	@ModelAttribute("genderList")
	public List<Gender> populate(){
		ArrayList<Gender> list=new ArrayList<>();
		Gender g1=new Gender();
		g1.setType("Male");
		list.add(g1);
		Gender g2=new Gender();
		g2.setType("Female");
		list.add(g2);
		return list;
	}
	@RequestMapping(value="reg",method=RequestMethod.POST)
	public ModelAndView register(Customer c,BindingResult errors,ModelMap map) {
		ModelAndView mv=new ModelAndView();
		validator.validate(c,errors);
		if(errors.hasErrors()) {
			mv.setViewName("register");
		}
		else {
			int row=customerDao.insert(c);
			if(row>0) {
			map.addAttribute("status", "successfully Registered");
			mv.setViewName("login");
			}
		}
		return mv;
		
	}
	
}










